// && AND 
// || OR
// ! NOT

// const a = 3;
// const b = -2;
//console.log(a < 0 || b >0) // true ou falso = true
            // false  false

// false = 0
// true  = 1            
  
let b = true;
 let result = b && (1/0)
 console.log(result)

//console.log(!false && !true)
             
// true || (false && false) 
// 2 === 3 || (4 < 0 && 1 === 1) 
// false  or (false e true )
// false  or false






