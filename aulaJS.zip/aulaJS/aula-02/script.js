// funcao- conjunto de codigo que executa e retorna algo
// executar ou invocar uma função

const nome = 'Everton'
const sobrenome = ' da Silva'

console.log(' inicio');

function ola(nome, idade, cidade) {
    return `${nome} ${idade}`
    // console.log('nome ', nome, ' idade : ',idade, 'cidade: ', cidade);
}

//function nomeCompleto(nome, sobrenome) {
  //  return `${nome} ${sobrenome}`
//}

const valor = function(nome, idade){
    console.log('nome: ', nome, 'idade: ', idade)
}

function teste(nome){
    console.log('ola teste ', nome);
}

const mostraOla = ola(nome,41,'Joinville/SC');

//console.log(mostraOla);

const nomeCompleto = (nome, sobrenome) => console.log(nome, sobrenome)

nomeCompleto(nome,sobrenome)
//`${nome} ${sobrenome}`

// valor(nome, idade)



//teste(nome);



