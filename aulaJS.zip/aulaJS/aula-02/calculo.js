//Escreva uma função chamada calculaMediaAnual que 
//aceite quatro números como parâmetros (notas) 
//e retorne a média aritmética dessas notas.

const notaTirada1 = 8;
const notaTirada2 = 7;
const notaTirada3 = 9;
const notaTirada4 = 6;

function calculaMediaAnual(nota1, nota2, nota3, nota4) {
    //Calcula a soma das notas
    const somaNotas = nota1 + nota2+ nota3 + nota4;
    const media = somaNotas / 4;
    return media;
}

const mediaAnual = calculaMediaAnual(notaTirada1,notaTirada2,notaTirada3, notaTirada4)

console.log('mediaAnual: ', mediaAnual);