let numero1 = 40
let numero2 = 5
let numero3 = 50

let numero4 = "40"

let numero5 = parseInt(numero4)

const totalSomado = function(valor1, valor2){
    const soma = valor1 + valor2
    console.log('soma ', soma)
}

const totalSubtrair = function(valor1, valor2){
    const subtr = valor1 - valor2
    console.log('subtração ',subtr)
}

const totalMultiplicar = function(valor1, valor2){
    const mult = valor1 * valor2
    console.log('multiplicacao ', mult)
}

const totalDividir = function(valor1, valor2){
    const dividi = valor1 / valor2
    console.log('divisao ' , dividi)
}

totalSubtrair(numero1,numero5)

totalSomado(numero1,numero3)

totalMultiplicar(numero1,numero3)

totalDividir(numero1,numero3)




// totalSomado(numero1,numero3)
