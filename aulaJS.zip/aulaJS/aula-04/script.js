console.log(' iniciado ....');
/*
let valores = 0;

// variavel de controle; logica de interrupção; variavel de controle
for (let i =0; i < 5;i++){ 
    valores += i; 
  // console.log(i);
}

//console.log(valores);

const test = [10];

const numeros = ['maça', // indice 0 
                 'banana', // indice 1
                 'laranja', // indice 2
                 'melancia',// indice 3
                 'melao',// indice 4
                 'pera'] // indice 5

console.log('quantidade '+ numeros.length)

for (let i =0; i <= numeros.length-1;i++){ 
  console.log(`na posição ${i} `+ 'tenho a fruta '+ numeros[i]);
}

*/

//Exercício 1: Soma de elementos
//Crie uma função que recebe um array de números como parâmetro e 
//retorna a soma de todos os elementos no array.

function somaArray(arr){
    let  soma = 0
    for(let i=0; i < arr.length; i++){
        soma += arr[i] 
    }
    return soma;
}

const meuArray = [1,2,3,4,5]
const resultado = somaArray(meuArray)

//console.log(resultado)

//Exercício 2: Maior elemento
 //Crie uma função que recebe um array de números como parâmetro e 
 //retorna o maior número no array.
 
 function encontrarMaiorNumero(arr){
    if (arr.length == 0){
        return undefined
    }
    
    let maior = arr[0];

    for (let i =1; i <arr.length; i++){
        if(arr[i] > maior){
            maior = arr[i]
        }
    }

    return maior;
 }
 const numeros = [100,5,80,20,3]

 const maiorNumero = encontrarMaiorNumero(numeros) 

 console.log(maiorNumero);

//Exercício 3: Média dos elementos
//Crie uma função que recebe um array de números como parâmetro e 
//retorna a média de todos os elementos no array.



//Exercício 4: Encontrar um elemento
//Crie uma função que recebe um array e um valor como parâmetros e 
//verifica se o valor está presente no array. A função deve retornar true
// se o valor estiver presente e false caso contrário.

function verificaValorNoArray(arr, valor) {
    if(arr.indexOf(valor) !== -1){
        return true
    }else {
        return false
    }
}

const meuArray1 = [1,2,3,4,5]

const valorProcurado = 3;

if(verificaValorNoArray(meuArray,valorProcurado)){
    console.log('Esta presente no array')
}else{
    console.log('Não esta presente')
}

                    0,      1,    2,     3,        4  , 5
const meuArray2 = ['maça','uva','pera','laranja','açai',"1"]
const meuArray3 = ['bergamota','tangirina', 'pocan']
const meuArray4 = [1,2,3,4,5]

//arr.length  // quantidade de itens do array
// console.log(meuArray2.includes('uva')) // retorna boolean 
//console.log(meuArray2.indexOf('uvas')); // retorna -1 se nãoexiste ou a posição do item
// console.log(meuArray2.concat(meuArray4)) // une dois ou mais arrays
// console.log(meuArray2.toString())
//console.log(meuArray2.join('; '))
//console.log(meuArray2.sort()) // ordena os itens por ordem alfa numerico

//console.log(meuArray2);
//console.log(meuArray2.splice(1,3)) 
//console.log(meuArray2.slice(2));
//console.log(meuArray2);

// meuArray2.unshift('bergamota') // empilha a partir da primeira
// meuArray2.shift()                // desenpilha  a partir da primeira
// console.log(meuArray2);
// meuArray2.push('bergamota') // enfileira no fim do array
// meuArray2.pop() // desinfileirar no fim do array
// console.log(meuArray2)



