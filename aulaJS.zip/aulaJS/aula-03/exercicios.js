 //Questão 1: Crie um programa em JavaScript que determine se um número é positivo,
 // negativo ou zero e exiba a mensagem correspondente.


 //console.log('tipo:', typeof numero);
 /*
 let numero = 10

 

 if (typeof numero === "number"){
    if(numero > 0){
        //positivo
        console.log(`o numero ${numero} é positivo`)
     }else if(numero < 0){
        // negativo
        console.log(`o numero ${numero} é negativo`)
     }else{
        // é zero
        console.log(`o numero ${numero} é zero`)
     }
 } else {
    console.log('Não é um numero valido')
 }
 */



// Questão 2: Escreva um programa em JavaScript que verifique se uma pessoa é 
// maior de idade (idade maior ou igual a 18) e exiba uma mensagem apropriada.

// let idade = 20

/*
if(idade >= 18){
    console.log("Você é maior de idade")
}else{
    console.log("Você é menor de idade")
}


const ehMaiorDeIdade = idade >= 18 ? "É maior de idade" : "É menor de idade"

console.log(ehMaiorDeIdade);
*/

// Questão 3: Crie um programa em JavaScript que converta um número de 1 a 7 
// em um dia da semana correspondente usando um switch-case.

/*
let numeroDia = 4
let diaDaSemana;

switch(numeroDia){
    case 1:
        diaDaSemana = "Domingo"
        break;
    case 2:
        diaDaSemana = "Segunda-feira"
        break;
    case 3:
        diaDaSemana = "Terça-feira"
        break;
    case 4:
        diaDaSemana = "Quarta-feira"
        break;
    case 5:
        diaDaSemana = "Quinta-feira"
        break;
    case 6:
        diaDaSemana = "Sexta-feira"
        break;
    case 7:
        diaDaSemana = "Sabado"
        break;
    default:
        diaDaSemana = "Número inválido"
}

console.log(`O numero ${numeroDia} corresponde a ` + diaDaSemana)
*/

//Verificação de Idade:
//Peça ao usuário para inserir sua idade e, em seguida, 
// use um bloco if-else para verificar se ele é maior de idade (18 anos ou mais) 
// ou menor de idade.


/*let idade = parseInt(prompt("Por favor, insira sua idade:"))

if(idade >= 18){
    console.log("Você é maior de idade")
}else{
    console.log("Você é menor de idade")
}
*/

// Maior de Três Números:
// Peça ao usuário para inserir três números e use estruturas condicionais 
// if e else
// para determinar qual deles é o maior.
/*
let numero1 = +prompt("Digite o primeiro numero:");
let numero2 = +prompt("Digite o segundo numero:");
let numero3 = +prompt("Digite o terceiro numero:");

if(numero1 >= numero2 && numero1 >= numero3){
    console.log(`O primeiro numero ${numero1} é o maior`);
}else if (numero2>= numero1 && numero2 >= numero3){
    console.log(`O segundo numero ${numero2} é o maior`);
}else{
    console.log(`O terceiro numero ${numero3} é o maior`);
}
*/






