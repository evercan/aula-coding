console.log(' exemplos de condicionais');


const a  = 10
const b  = true
const c = false
const d = "Everton"

console.log('---- inicial ----');

// 2 === 3 || (4 < 0 && 1 === 1) 

if(a >= 10 && b == true && c == false) {
    // console.log(' o valor é maior que 10');
    const numero = 1
    const somaTotal = numero + a
    if(somaTotal < 11){
        console.log("valor igual a 11");
    }else{
        console.log('erro valor')
    }
}else if (a == 10 && b == false && c == false){
} else { 
    console.log(' O valor não é maior ');
}

/*

if(a > 10) {
    console.log(' o valor é maior que 10');
} else if (a >= 10){    
    console.log(' O valor é igual a 10');
} else {
    console.log(' O valor não é maior ');
}
*/

// estrutura do switch

const deletarRegistros = function(parametros){
    return 'Arquivo deletado com sucesso'
    
}

const opcao = 5
const registro = " "

switch(opcao){
    case 1:        
        console.log('lista')
        break;
    case 5:
        deletarRegistros(registro)
        console.log('deleta')
        break;
    case 10:
        console.log('sai')
        break;
    default:
        console.log('não entendi')
}