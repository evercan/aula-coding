
var i = 0;

while(i < 10){         
    console.log(i);
    i++; 
    if(i == 5){
        console.log('parou no 5')
        break;
    }
}

console.log('termino do while')

// incrementar  ++
// decrementar  --