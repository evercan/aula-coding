console.log("conteudo da pagina")

// Camada de Armazenamento (Variaveis)

let nomeCompleto  = "Everton";
let idade = 41;
const Pi = 3.14;
const alto = true;

var a = 1;
console.log(alto);


//console.log(alto)

let animal = "elefante"

{
    const alto = "gato"
    console.log(alto);
}





//var b =2, c = 3

// console.log(b, c);

//var f = g = 5;

//console.log(f,g);

//var h = i, i = 6
//console.log(h, i)

//var j = k = l = m = 7, n=k
//console.log(j,k,l,m,n)


// Camada de Instruções (Comandos)

// window.alert("Cadastro Efetuado com sucesso");

//confirm("Voce é maior de idade");

//nome = prompt("Digite seu nome", "Seu nome aqui");

//console.log(nome);

// console.log("idade", idade, "nome", nomeCompleto)

console.log(a);